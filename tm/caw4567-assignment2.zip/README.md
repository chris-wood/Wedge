Wedge - Password cracking tool
==========

A simple Python-based password cracking tool that utilizes dictionary and brute-force attacks. 

Rainbow tables and markov-chain based approaches are expected in future releases.