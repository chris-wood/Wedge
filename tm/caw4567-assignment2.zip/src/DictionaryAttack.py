################################################################
#
# File: DictionaryAttack.py
# Author: Christopher A. Wood, caw4567@rit.edu
# Version: 12/8/12
#
################################################################

import threading
import hashlib # ('md5', 'sha1', 'sha224', 'sha256', 'sha384', 'sha512')
import crypt # crypt(3)
import sys # for command-line arguments and file I/O 

class DictionaryAttack(threading.Thread):
    ''' This thread is responsible for running a dictionary attack 
    to crack an encrypted password. 
    '''
    def __init__(self, digest, format, dictionary):
        ''' Constructor - save the password, hash function, and wordlist reference
        '''
        # Call the thread constructor
        threading.Thread.__init__(self)

        # Save the variables
        self.digest = digest
        self.format = format
        self.dictionary = dictionary
        self.cracked = False
        self.password = None

    def get_result(self):
        ''' Retrieve the result from running this attack
        '''
        return self.cracked, self.password

    def compare_password_hashes(self, word):
        ''' Compare the digest of the specified word against the password digest.
        '''
        match = False

        # Determine the hash function type
        # NOTE: this had to be done in local scope to produce the correct hash digest.
        h = hashlib.md5()
        if (self.format == "crypt"):
            pass # defaults to md5 because we aren't handling salted passwords yet
        elif (self.format == "md5"):
            h = hashlib.md5()
        elif (self.format == "sha1"):
            h = hashlib.sha1()
        elif (self.format == "sha256"):
            h = hashlib.sha256()
        elif (self.format == "sha512"):
            h = hashlib.sha512()

        # Perform the computation and comparison
        h.update(word)
        if (h.digest() == self.digest):
            match = True
        return match

    def run(self):
        ''' Attempt to crack the password using the dictionary attack, which
        walks the wordlist in search of a comparable password hash digest.
        
        The supported hash functions are: md5, sha1, sha225, sha256, sha384, sha512, crypt
        '''
        self.cracked = False
        try:
            # Proceed with the attack...
            with open(self.dictionary) as f: 
                for word in f.readlines():
                    if (self.compare_password_hashes(word.rstrip('\n'))):
                        self.password = word.rstrip('\n')
                        self.cracked = True
                        return self.cracked # early return to avoid wasted cycles
        except Exception as e:
            print(e)
            raise Exception("Error occurred while cracking password")

        # Return the result...
        return self.cracked